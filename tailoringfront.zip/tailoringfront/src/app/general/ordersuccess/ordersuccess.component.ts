import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ordersuccess',
  templateUrl: './ordersuccess.component.html',
  styleUrls: ['./ordersuccess.component.css']
})
export class OrdersuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    localStorage.removeItem("products");
  }

}
