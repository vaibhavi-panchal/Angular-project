let mongoose = require("mongoose");
let Schema = mongoose.Schema;
let schema = new Schema(
    {
        name: { type: String, required: true },
        product: { type: String, required: true },
        height: { type: String, required: true },
        weight: { type: String, required: true },
        wrist: { type: String, required: true },
        shoulder: { type: String, required: true },
        chest: { type: String, required: true },
        waist: { type: String, required: true },
        outseam: { type: String, required: true },
        inseam: { type: String, required: true }
    }
);
let Measurement = mongoose.model("measurements", schema);
module.exports = Measurement;